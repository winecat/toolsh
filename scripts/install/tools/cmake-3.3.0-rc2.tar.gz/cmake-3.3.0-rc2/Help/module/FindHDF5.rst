.. cmake-module:: ../../Modules/FindHDF5.cmake
