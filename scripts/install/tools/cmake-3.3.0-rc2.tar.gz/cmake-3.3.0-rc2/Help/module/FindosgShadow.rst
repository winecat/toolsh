.. cmake-module:: ../../Modules/FindosgShadow.cmake
