break
-----

Break from an enclosing foreach or while loop.

::

  break()

Breaks from an enclosing foreach loop or while loop

See also the :command:`continue` command.
